#!/bin/bash
sh build.sh
cd bin
./CodeCraft-2019 ../config/car.txt ../config/road.txt ../config/cross.txt ../config/answer.txt